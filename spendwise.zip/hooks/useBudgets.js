"use client";
import { useEffect, useState } from "react";

const STORAGE_KEY = "spendwise:budgets:v1";

export function useBudgets() {
  const [budgets, setBudgets] = useState({}); // empty on SSR

  // hydrate on client
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      setBudgets(raw ? JSON.parse(raw) : {});
    } catch {}
  }, []);

  // persist on change
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(budgets)); } catch {}
  }, [budgets]);

  function setBudget(category, amount) {
    setBudgets((b) => ({ ...b, [category]: Number(amount) || 0 }));
  }
  function removeBudget(category) {
    setBudgets((b) => {
      const copy = { ...b };
      delete copy[category];
      return copy;
    });
  }
  function clearBudgets() { setBudgets({}); }

  return { budgets, setBudget, removeBudget, clearBudgets };
}

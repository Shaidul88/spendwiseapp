"use client";
import { useEffect, useRef, useState, useMemo, useCallback } from "react";

const KEY = "spendwise:expenses:v1";

function read() {
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "[]");
  } catch {
    return [];
  }
}

export function useExpenses() {
  const [items, setItems] = useState([]);        // empty on SSR
  const hydratedRef = useRef(false);             // prevents early save

  // 1) Hydrate once on client
  useEffect(() => {
    setItems(read());
    hydratedRef.current = true;
  }, []);

  // 2) Persist only AFTER hydration
  useEffect(() => {
    if (!hydratedRef.current) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(items));
    } catch {}
  }, [items]);

  // Optional: keep multiple tabs in sync
  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === KEY) {
        try {
          setItems(JSON.parse(e.newValue ?? "[]") || []);
        } catch {}
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const addExpense = useCallback((e) => {
    const newItem = {
      id: e.id ?? crypto.randomUUID(),
      title: (e.title ?? "").trim(),
      amount: Number(e.amount) || 0,
      category: e.category || "Other",
      date: e.date || new Date().toISOString().slice(0, 10),
      note: e.note || "",
    };
    setItems((prev) =>
      [newItem, ...prev].sort((a, b) => String(b.date).localeCompare(String(a.date)))
    );
  }, []);

  const updateExpense = useCallback(
    (id, patch) => setItems((x) => x.map((e) => (e.id === id ? { ...e, ...patch } : e))),
    []
  );

  const removeExpense = useCallback((id) => setItems((x) => x.filter((e) => e.id !== id)), []);
  const clearAll = useCallback(() => setItems([]), []);

  const stats = useMemo(() => {
    const total = items.reduce((s, x) => s + (Number(x.amount) || 0), 0);
    return { count: items.length, total };
  }, [items]);

  return { items, addExpense, updateExpense, removeExpense, clearAll, stats, hydrated: hydratedRef.current };
}

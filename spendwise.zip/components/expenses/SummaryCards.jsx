"use client";
import React, { useMemo } from "react";

// stable money formatting across SSR/CSR
function money(n) {
  return Number(n || 0).toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
  });
}

export default function SummaryCards({ items = [] }) {
  const { total, avg, count } = useMemo(() => {
    const arr = Array.isArray(items) ? items : [];
    const total = arr.reduce((s, e) => s + Number(e?.amount || 0), 0);
    const count = arr.length;
    const avg = count ? total / count : 0;
    return { total, avg, count };
  }, [items]);

  const card = "p-4 rounded-2xl bg-neutral-800 text-neutral-100 ring-1 ring-neutral-700";
  const label = "text-xs text-neutral-400";

  return (
    <div className="grid sm:grid-cols-3 gap-3">
      <div className={card}>
        <div className={label}>All-time total</div>
        <div className="text-xl font-semibold" suppressHydrationWarning>
          {money(total)}
        </div>
      </div>

      <div className={card}>
        <div className={label}>Average per item</div>
        <div className="text-xl font-semibold" suppressHydrationWarning>
          {money(avg)}
        </div>
      </div>

      <div className={card}>
        <div className={label}>Items</div>
        <div className="text-xl font-semibold" suppressHydrationWarning>
          {count}
        </div>
      </div>
    </div>
  );
}

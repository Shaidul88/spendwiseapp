"use client";

import { useEffect, useMemo, useState } from "react";
import { useExpenses } from "@/hooks/useExpenses";

// ------- helpers -------
const ALL = "All";
const CATEGORIES = [
  "Food", "Grocery", "Transport", "Shopping",
  "Bills", "Entertainment", "Health", "Other",
];

function fmtMoney(n) {
  return Number(n || 0).toLocaleString("en-US", { style: "currency", currency: "USD" });
}
function toISODate(d) {
  return new Date(d).toISOString().slice(0, 10);
}
function monthKey(d) {
  return new Date(d).toISOString().slice(0, 7); // YYYY-MM
}
function useMounted() {
  const [m, setM] = useState(false);
  useEffect(() => setM(true), []);
  return m;
}

// ------- page -------
export default function ReportsPage() {
  // call hooks unconditionally (fixes hook-order warnings)
  const mounted = useMounted();
  const { items } = useExpenses();

  // filters
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [cat, setCat] = useState(ALL);

  // set default range to this month on client (avoid SSR time drift)
  useEffect(() => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    setFrom(toISODate(start));
    setTo(toISODate(now));
  }, []);

  // filtered rows
  const rows = useMemo(() => {
    const arr = Array.isArray(items) ? items : [];
    return arr.filter((e) => {
      if (!e?.date) return false;
      const d = toISODate(e.date);
      if (from && d < from) return false;
      if (to && d > to) return false;
      if (cat !== ALL && e.category !== cat) return false;
      return true;
    }).sort((a, b) => String(b.date).localeCompare(String(a.date)));
  }, [items, from, to, cat]);

  // summary
  const { total, count, avgPerTxn, avgPerDay, uniqueDays } = useMemo(() => {
    let total = 0;
    const days = new Set();
    for (const r of rows) {
      total += Number(r?.amount || 0);
      if (r?.date) days.add(toISODate(r.date));
    }
    const count = rows.length;
    const uniqueDays = days.size || 1;
    const avgPerTxn = count ? total / count : 0;
    const avgPerDay = uniqueDays ? total / uniqueDays : 0;
    return { total, count, avgPerTxn, avgPerDay, uniqueDays };
  }, [rows]);

  // by category
  const byCat = useMemo(() => {
    const map = new Map();
    for (const r of rows) {
      const k = r?.category || "Uncategorized";
      map.set(k, (map.get(k) || 0) + Number(r?.amount || 0));
    }
    const out = [...map.entries()].map(([k, v]) => ({ category: k, total: v }));
    out.sort((a, b) => b.total - a.total);
    const grand = out.reduce((s, x) => s + x.total, 0) || 1;
    return { list: out, grand };
  }, [rows]);

  // by month (YYYY-MM)
  const byMonth = useMemo(() => {
    const map = new Map();
    for (const r of rows) {
      const k = monthKey(r?.date || new Date());
      map.set(k, (map.get(k) || 0) + Number(r?.amount || 0));
    }
    const out = [...map.entries()].map(([k, v]) => ({ month: k, total: v }));
    out.sort((a, b) => a.month.localeCompare(b.month));
    const max = out.reduce((m, x) => Math.max(m, x.total), 0) || 1;
    return { list: out, max };
  }, [rows]);

  // export CSV (client-only)
  function exportCSV() {
    const headers = ["title", "amount", "category", "date", "note"];
    const lines = [headers.join(",")];
    for (const r of rows) {
      const vals = [
        (r?.title ?? "").toString().replaceAll('"', '""'),
        Number(r?.amount || 0),
        r?.category ?? "",
        toISODate(r?.date ?? new Date()),
        (r?.note ?? "").toString().replaceAll('"', '""'),
      ];
      lines.push(vals.map((v) => (typeof v === "string" ? `"${v}"` : v)).join(","));
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `spendwise-report_${from || "all"}_${to || "all"}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  // skeleton AFTER hooks are defined (no hook-order issues)
  if (!mounted || !from || !to) {
    return (
      <main className="p-6 space-y-6">
        <div className="h-6 w-40 bg-neutral-800 rounded" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="h-16 bg-neutral-900 border border-neutral-800 rounded-2xl" />
          <div className="h-16 bg-neutral-900 border border-neutral-800 rounded-2xl" />
          <div className="h-16 bg-neutral-900 border border-neutral-800 rounded-2xl" />
          <div className="h-16 bg-neutral-900 border border-neutral-800 rounded-2xl" />
        </div>
        <div className="h-40 bg-neutral-900 border border-neutral-800 rounded-2xl" />
      </main>
    );
  }

  return (
    <main className="p-6 space-y-6">
      {/* Header + filters */}
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Reports</h1>
          <p className="text-sm text-gray-400">Analyze spending over any date range and export results.</p>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div>
            <label className="text-xs block mb-1">From</label>
            <input
              type="date"
              className="bg-neutral-900 border border-neutral-700 rounded-md px-3 py-2 text-sm"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs block mb-1">To</label>
            <input
              type="date"
              className="bg-neutral-900 border border-neutral-700 rounded-md px-3 py-2 text-sm"
              value={to}
              onChange={(e) => setTo(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs block mb-1">Category</label>
            <select
              className="bg-neutral-900 border border-neutral-700 rounded-md px-3 py-2 text-sm"
              value={cat}
              onChange={(e) => setCat(e.target.value)}
            >
              <option value={ALL}>{ALL}</option>
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => window.print()}
              className="px-3 py-2 rounded-xl border border-neutral-700 hover:bg-neutral-800 text-sm"
            >
              Print
            </button>
            <button
              onClick={exportCSV}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-neutral-700 text-sm"
            >
              Export CSV
            </button>
          </div>
        </div>
      </header>

      {/* Summary cards */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <Card label="Total Spent" value={fmtMoney(total)} />
        <Card label="Transactions" value={count} />
        <Card label="Avg / Txn" value={fmtMoney(avgPerTxn)} />
        <Card label={`Avg / Day (${uniqueDays}d)`} value={fmtMoney(avgPerDay)} />
      </section>

      {/* Category breakdown */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900 p-4">
          <div className="font-medium mb-3">By Category</div>
          <div className="space-y-3">
            {byCat.list.length === 0 && (
              <div className="text-sm text-gray-400">No expenses for this range.</div>
            )}
            {byCat.list.map((row) => {
              const pct = Math.round((row.total / (byCat.grand || 1)) * 100);
              return (
                <div key={row.category}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{row.category}</span>
                    <span className="text-gray-400" suppressHydrationWarning>
                      {fmtMoney(row.total)} • {pct}%
                    </span>
                  </div>
                  <div className="h-2 w-full bg-neutral-800 rounded-full overflow-hidden">
                    <div className="h-full bg-green-500" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Monthly mini-bars */}
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900 p-4">
          <div className="font-medium mb-3">Monthly Trend</div>
          {byMonth.list.length === 0 ? (
            <div className="text-sm text-gray-400">No data in selected range.</div>
          ) : (
            <div className="space-y-2">
              {byMonth.list.map((row) => {
                const pct = Math.round((row.total / (byMonth.max || 1)) * 100);
                return (
                  <div key={row.month}>
                    <div className="flex justify-between text-sm mb-1">
                      <span>{row.month}</span>
                      <span className="text-gray-400" suppressHydrationWarning>
                        {fmtMoney(row.total)}
                      </span>
                    </div>
                    <div className="h-2 w-full bg-neutral-800 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Transactions table */}
      <section className="rounded-2xl border border-neutral-800 bg-neutral-900 p-4">
        <div className="font-medium mb-3">Transactions</div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="text-left text-gray-400 border-b border-neutral-800">
              <tr>
                <th className="py-2 pr-4">Date</th>
                <th className="py-2 pr-4">Title</th>
                <th className="py-2 pr-4">Category</th>
                <th className="py-2 pr-4 text-right">Amount</th>
                <th className="py-2">Note</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-b border-neutral-800/60">
                  <td className="py-2 pr-4">{toISODate(r?.date ?? new Date())}</td>
                  <td className="py-2 pr-4">{r?.title ?? "-"}</td>
                  <td className="py-2 pr-4">{r?.category ?? "-"}</td>
                  <td className="py-2 pr-4 text-right" suppressHydrationWarning>{fmtMoney(r?.amount || 0)}</td>
                  <td className="py-2">{r?.note ?? ""}</td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-gray-400">
                    No transactions in this range.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}

// ------- small components -------
function Card({ label, value }) {
  return (
    <div className="rounded-2xl border border-neutral-800 bg-neutral-900 p-4">
      <div className="text-xs text-gray-400">{label}</div>
      <div className="text-xl font-semibold mt-1" suppressHydrationWarning>{value}</div>
    </div>
  );
}

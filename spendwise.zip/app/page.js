// app/page.js
import DashboardPage from "./dashboard/page";

export default function Index() {
  return <DashboardPage />;
}
